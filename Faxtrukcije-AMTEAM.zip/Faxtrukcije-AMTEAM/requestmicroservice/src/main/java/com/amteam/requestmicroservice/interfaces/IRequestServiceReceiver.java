package com.amteam.requestmicroservice.interfaces;

public interface IRequestServiceReceiver {
    public void receive(String content);
}
