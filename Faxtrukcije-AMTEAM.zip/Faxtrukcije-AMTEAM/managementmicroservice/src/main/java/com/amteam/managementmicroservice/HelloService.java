package com.amteam.managementmicroservice;

public interface HelloService {
}
