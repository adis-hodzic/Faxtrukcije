package com.amteam.managementmicroservice.interfaces;

public interface IManagementServiceReceiver {
    public void receive(String content);
}
